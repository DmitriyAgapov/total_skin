/*Grid*/
export const gridColumns =  `repeat(12, 1fr)`;
export const gridColumns_tablet =  `repeat(9, 1fr)`;
export const gridGap = `2em`;
export const gridSectionRow = `minmax(10vh, auto) 1fr minmax(10vh, auto)`;